package net.sqlitetutorial;

public class Sale {
    // SaleNr, Location, Time, PaymentID
}