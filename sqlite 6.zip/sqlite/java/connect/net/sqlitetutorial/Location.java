package net.sqlitetutorial;

import java.util.Scanner;

public class Location {

    //LocationID, Address, LocationName, Capacity
    private int LocationID;
    private String Address;
    private String LocationName;
    private int Capacity;

    //Konstruktor
    public Location() {
        LocationID = LocationID();
        Address = Address();
        LocationName = LocationName();
        Capacity = Capacity();

        System.out.println(LocationID + " " + Address + " " + LocationName + " " + Capacity);
    }
    //set LocationID
    private int LocationID() {
        System.out.println("Insert location ID");
        Scanner locId = new Scanner(System.in);
        String loc = locId.nextLine();
        int fin = Integer.parseInt(loc);

        return fin;

    }
    //set Address
    private String Address () {
        System.out.println("Insert Address");
        Scanner ad = new Scanner(System.in);
        String adr = ad.nextLine();

        return adr;

    }
    //set LocationName
    private String LocationName () {
        System.out.println("Insert location name");
        Scanner locName = new Scanner(System.in);
        String ln = locName.nextLine();

        return ln;
    }
    //set Capacity
    private int Capacity () {
        System.out.println("Insert capacity");
        Scanner cap = new Scanner(System.in);
        String capa = cap.nextLine();
        int fin = Integer.parseInt(capa);

        return fin;
    }
}